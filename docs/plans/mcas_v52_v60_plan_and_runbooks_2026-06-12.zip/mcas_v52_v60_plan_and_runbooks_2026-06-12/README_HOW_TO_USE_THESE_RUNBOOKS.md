# How to use these v52-v60 plan files

Generated: 2026-06-12  
Target repository: `/Users/andy/Documents/project/multi-coding-agent-symphony`

## Files

- `mcas-v52-v60-master-plan-2026-06-12.md`
- `runbooks/v52-system-golden-path-closeout-runbook-2026-06-12.md`
- `runbooks/v53-controlled-child-dispatch-preview-runbook-2026-06-12.md`
- `runbooks/v54-codex-provider-execution-pilot-runbook-2026-06-12.md`
- `runbooks/v55-claude-code-provider-parity-result-return-runbook-2026-06-12.md`
- `runbooks/v56-thread-continuation-handoff-pack-runbook-2026-06-12.md`
- `runbooks/v57-review-gate-workbench-surface-runbook-2026-06-12.md`
- `runbooks/v58-local-mac-app-bundle-packaging-evidence-runbook-2026-06-12.md`
- `runbooks/v59-dual-provider-multi-agent-e2e-runbook-2026-06-12.md`
- `runbooks/v60-stable-personal-workbench-release-runbook-2026-06-12.md`

## Copy target

Copy the runbooks into:

```text
docs/plans/
```

Suggested command from the extracted folder:

```sh
cp runbooks/*.md /Users/andy/Documents/project/multi-coding-agent-symphony/docs/plans/
cp mcas-v52-v60-master-plan-2026-06-12.md /Users/andy/Documents/project/multi-coding-agent-symphony/docs/plans/
```

## Provider correction

Forward versions only support:

```text
codex
claude-code
```

If older docs still mention other providers, treat those as historical references. Do not carry them into v52-v60 runtime contracts, Workbench UI, provider tests, or acceptance evidence.

## Recommended next step

After v51 is implemented and closed, start with:

```text
docs/plans/v52-system-golden-path-closeout-runbook-2026-06-12.md
```

Do not jump straight to v54 provider execution. v52 proves the daily path. v53 creates safe child task packs. v54 starts the first narrow Codex execution pilot.
