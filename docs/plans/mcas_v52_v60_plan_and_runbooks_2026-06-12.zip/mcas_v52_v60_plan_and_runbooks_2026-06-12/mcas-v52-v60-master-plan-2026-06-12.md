# multi-coding-agent-symphony v52-v60 Master Plan

Date: 2026-06-12  
Timezone: Asia/Shanghai  
Baseline assumption: v51 `result-intake-evidence-escrow` is the immediate prerequisite.  
Supported providers from v52 onward: `codex` and `claude-code` only.

## Purpose

This plan turns `multi-coding-agent-symphony` from a supervised workflow/workbench into a stable personal development workbench baseline by v60.

The important correction for this planning cycle is provider scope:

```text
supportedProviders = ["codex", "claude-code"]
```

Any legacy or historical provider names in older docs should not be carried forward into v52-v60 runtime contracts, Workbench labels, provider matrices, tests, or acceptance evidence.

## Version Spine

```text
v51 Result Intake Evidence Escrow
  -> v52 System Golden Path Closeout
  -> v53 Controlled Child Dispatch Preview
  -> v54 Codex Provider Execution Pilot
  -> v55 Claude Code Provider Parity + Result Return
  -> v56 Thread Continuation Handoff Pack
  -> v57 Review / Gate Workbench Surface
  -> v58 Local Mac App Bundle Packaging Evidence
  -> v59 Dual-Provider Multi-Agent E2E Run
  -> v60 Stable Personal Workbench Release
```

## Desired v60 State

By v60, the system should support the daily personal workbench loop:

```text
Open local Workbench / Mac app shell
-> select current project
-> inspect active goal, next action, supervisor state, and context advisory
-> preview a child task pack
-> execute a controlled Codex or Claude Code provider task
-> capture provider result
-> sanitize and escrow result through v51 result intake
-> preview and confirm goal event through controlled planHash paths
-> review and gate with provider separation and explicit operator confirmation
-> create continuation / handoff packs when context is near limit
-> close out the version with evidence, release notes, and next-version handoff
```

v60 should be a stable personal baseline, not a public SaaS product and not a signed public distribution.

## Non-Negotiable Boundaries

These boundaries apply across v52-v60 unless a specific later runbook explicitly narrows and authorizes a controlled exception.

- No generic shell runner.
- No browser terminal.
- No arbitrary command execution from the renderer.
- No provider name outside `codex` and `claude-code`.
- No frontend reads of provider JSONL, local session files, transcript folders, `.symphony` internals, goal ledgers, or event logs.
- No raw transcript or raw model output exposure in Workbench.
- No provider result may directly append a goal event.
- No provider result may directly mark a task complete.
- No provider result may directly approve its own work.
- No automatic compact or new-thread creation.
- No git push, tag, publish, GitHub Release creation, or release automation from Workbench.
- No claim of signed distribution, notarization, auto-update, or public `.dmg` until a later packaging/release runbook proves it.

## Provider Policy

### Supported

| Provider id | Use | First version |
| --- | --- | --- |
| `codex` | Worker implementation pilot, later reviewer or secondary worker when separated from its own output | v54 |
| `claude-code` | Provider parity, reviewer path, alternate worker | v55 |

### Provider separation rule

When a provider performs the worker implementation, review should prefer the other provider or an explicit human review result.

Examples:

```text
Codex worker -> Claude Code reviewer
Claude Code worker -> Codex reviewer
Provider worker -> human reviewer
```

The same provider may not silently approve its own work. Any exception must require explicit operator confirmation and a recorded reason.

## Version Summary

| Version | Main outcome | Execution level | Handoff |
| --- | --- | --- | --- |
| v52 | Daily Golden Path readiness from Project Launcher to Closeout | Read-only + controlled state projection | v53 child dispatch preview |
| v53 | Child task pack preview and copy-only dispatch preparation | Preview/copy only | v54 Codex execution pilot |
| v54 | Controlled Codex execution pilot with result returning to v51 intake | Narrow provider execution | v55 Claude Code parity |
| v55 | Claude Code parity and shared provider result return | Two-provider controlled execution | v56 thread handoff |
| v56 | Continuation/compact/new-thread handoff packs | Copy-only; checkpoint artifact only | v57 review/gate surface |
| v57 | Review/gate readiness and controlled planHash confirmation | Controlled review/gate, not auto approval | v58 local app bundle |
| v58 | Local Mac app bundle and packaging evidence | Local desktop packaging; no public distribution | v59 dual-provider E2E |
| v59 | Dual-provider multi-agent E2E proof | Controlled execution with provider separation | v60 stable baseline |
| v60 | Stable personal Workbench release | Stabilization, docs, acceptance, tag prep | post-v60 maintenance |

## Cross-Version Contract Spine

The following contracts/read models should be treated as the product spine.

```text
project-registry.v1
current-project-binding.v1
project-health-snapshot.v1
goal-supervisor-app-read-model.v1
contextAdvisory.v1
threadContinuationDecision.v1
resultIntakeRequest.v1
resultIntakePreview.v1
resultEvidenceEscrow.v1
pendingResult.v1
supervisorEventRegistrationEligibility.v1
goal-update-plan.v1
goal-event-confirmation.v1
systemGoldenPath.v1
childDispatchPreview.v1
childTaskPack.v1
providerExecutionPreview.v1
providerExecutionResult.v1
threadHandoffPack.v1
reviewGateReadiness.v1
multiAgentRunEvidence.v1
stableWorkbenchRelease.v1
```

## Standard PR Shape

Each version should follow the same reviewable sequence unless the runbook narrows it.

```text
PR-0: runbook only
PR-1: contracts / fixtures / tests
PR-2: backend or CLI projection
PR-3: Workbench surface or execution integration
PR-4: acceptance evidence
PR-5: closeout snapshot and next-version handoff
```

For execution versions v54, v55, and v59, add an explicit provider smoke/evidence PR when needed.

## Common Validation Commands

Use the version-specific runbook first. These commands are the baseline matrix:

```sh
pnpm workbench:build
node --test tests/workbench-api-client.test.js tests/workbench-shell.test.js tests/workbench-route-smoke.test.js
pnpm check
git diff --check
```

When a version touches shared contract helpers, console routes, ArtifactStore, goal event command paths, provider adapters, or generated Workbench assets in broad ways, run:

```sh
pnpm test
```

Provider-specific checks are opt-in and must not become default CI if they require credentials or real model spend.

```sh
pnpm smoke:codex:help
pnpm smoke:claude:help
```

Real provider smokes must be explicitly authorized per runbook and recorded with provider, command shape, workspace, result refs, and cost/usage if available.

## Target File Placement

Copy these generated runbooks into:

```text
docs/plans/
```

Suggested files:

```text
docs/plans/v52-system-golden-path-closeout-runbook-2026-06-12.md
docs/plans/v53-controlled-child-dispatch-preview-runbook-2026-06-12.md
docs/plans/v54-codex-provider-execution-pilot-runbook-2026-06-12.md
docs/plans/v55-claude-code-provider-parity-result-return-runbook-2026-06-12.md
docs/plans/v56-thread-continuation-handoff-pack-runbook-2026-06-12.md
docs/plans/v57-review-gate-workbench-surface-runbook-2026-06-12.md
docs/plans/v58-local-mac-app-bundle-packaging-evidence-runbook-2026-06-12.md
docs/plans/v59-dual-provider-multi-agent-e2e-runbook-2026-06-12.md
docs/plans/v60-stable-personal-workbench-release-runbook-2026-06-12.md
```

## Recommended Execution Order

Do not start v53 until v52 acceptance proves the daily path can see v51 result intake and v50 event registration together.

Do not start v54 until v53 produces safe child task packs.

Do not start v55 until Codex execution result returns through v51 intake without direct goal event append.

Do not start v59 until both Codex and Claude Code use the same result-return pipeline.

Do not call v60 stable until v59 proves at least one full dual-provider run with review separation, explicit evidence, and no forbidden Workbench controls.
