# v56 Thread Continuation Handoff Pack Runbook

Date: 2026-06-12  
Timezone: Asia/Shanghai  
Goal id: `v56-thread-continuation-handoff-pack`  
Branch draft: `codex/v56-thread-continuation-handoff-pack`  
Baseline: v55 `claude-code-provider-parity-result-return` merged, tagged, and accepted.  
Supported providers: `codex`, `claude-code` only.

## Objective

v56 turns context advisory into usable continuation artifacts for Codex and Claude Code.

It should generate copy-only handoff packs for:

```text
continue
checkpoint
compact
new-thread
recover-drift
blocked
```

It must not automatically compact transcripts, create new provider threads, or read provider session files from the frontend.

## Product Problem

By this stage the Workbench can run controlled provider tasks. Long-running work needs safe continuation material so the operator can move between sessions without losing the goal state, evidence refs, boundaries, and next action.

v56 answers:

```text
What should I paste into the next Codex or Claude Code session?
What is safe to carry forward?
Which raw context is intentionally excluded?
Which evidence refs prove the state?
```

## Boundary Decision

v56 may generate handoff artifacts. It may not create provider sessions.

Allowed:

- backend-owned handoff pack generation;
- copy-only provider-specific prompts;
- checkpoint artifact storage;
- context advisory summaries;
- evidence refs;
- source contract refs.

Forbidden:

- automatic compact;
- automatic new-thread;
- provider launch;
- frontend local session reads;
- raw transcript display.

## Global Forbidden Scope

This version must not add or imply:

- provider names outside `codex` and `claude-code`;
- generic shell or terminal UI;
- arbitrary renderer-side command execution;
- frontend reads of local JSONL/session files, provider transcript folders, `.symphony` internals, goal ledgers, or event logs;
- raw transcript or raw model output exposure in Workbench;
- direct goal event append from provider or child output;
- direct task completion from provider output;
- automatic self-review;
- git write, merge, push, tag, publish, GitHub Release creation, or release automation;
- signed distribution, notarization, auto-update, or public `.dmg` claims unless this version explicitly proves them.

## Contracts

Add:

```text
threadHandoffPack.v1
providerContinuationPrompt.v1
checkpointSnapshot.v1
contextCarryoverRefs.v1
threadBoundaryNotice.v1
```

`threadHandoffPack.v1` fields:

```text
goalId
projectId
generatedAt
decision
providerTargets: codex | claude-code
summary
knownFacts[]
openRisks[]
nextSafeAction
requiredEvidenceRefs[]
sourceContracts[]
forbiddenActions[]
copyBlocks[]
checkpointRef
```

`copyBlocks[]` should include separate blocks for Codex and Claude Code, but both must come from the same bounded source model.

## Workbench Surface

Allowed labels:

```text
Preview Handoff Pack
Copy Codex Handoff
Copy Claude Code Handoff
Create Checkpoint Snapshot
Refresh Context Advisory
```

`Create Checkpoint Snapshot` may write a safe handoff artifact only. It must not create provider threads.

Forbidden labels:

```text
Compact Now
Create New Thread
Launch Provider
Read Session File
Open Transcript
```

## PR Breakdown

### PR-0: Runbook

Add this runbook only.

### PR-1: Contracts And Fixtures

Fixtures:

```text
thread-handoff-pack.continue.v1.json
thread-handoff-pack.compact.v1.json
thread-handoff-pack.new-thread.v1.json
thread-handoff-pack.recover-drift.v1.json
thread-handoff-pack.blocked.v1.json
```

Tests:

```sh
node --test tests/v56-thread-continuation-handoff-pack.test.js
```

### PR-2: Backend Handoff Projection

Scope:

- consume context advisory and Golden Path state;
- create provider-specific copy blocks;
- exclude raw transcript;
- preserve source refs.

### PR-3: Checkpoint Snapshot

Scope:

- safe checkpoint artifact only;
- no provider session creation;
- no transcript compaction.

### PR-4: Workbench Handoff Panel

Scope:

- render decision;
- render copy-only prompts;
- render checkpoint ref;
- assert forbidden controls absent.

### PR-5: Acceptance And v57 Handoff

Acceptance should prove both Codex and Claude Code handoff blocks are generated and copyable, and no provider session is created.

## Validation Commands

```sh
pnpm workbench:build
node --test tests/v56-thread-continuation-handoff-pack.test.js
node --test tests/v55-provider-policy.test.js
node --test tests/v52-system-golden-path.test.js
node --test tests/workbench-api-client.test.js tests/workbench-shell.test.js tests/workbench-route-smoke.test.js
pnpm check
git diff --check
```

## Rollback Path

If handoff packs expose raw transcript or local session paths, revert PR-2/PR-4.

If checkpoint writes unsafe data, revert PR-3 and keep copy-only handoffs.

## v57 Handoff

v57 should create a Review/Gate Workbench surface with provider separation. It may add controlled review/gate preview/confirm only under a separate planHash path and explicit operator confirmation.
