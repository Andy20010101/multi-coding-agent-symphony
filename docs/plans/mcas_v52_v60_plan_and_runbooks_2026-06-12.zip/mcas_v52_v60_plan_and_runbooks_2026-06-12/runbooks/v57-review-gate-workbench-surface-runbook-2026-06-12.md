# v57 Review Gate Workbench Surface Runbook

Date: 2026-06-12  
Timezone: Asia/Shanghai  
Goal id: `v57-review-gate-workbench-surface`  
Branch draft: `codex/v57-review-gate-workbench-surface`  
Baseline: v56 `thread-continuation-handoff-pack` merged, tagged, and accepted.  
Supported providers: `codex`, `claude-code` only.

## Objective

v57 makes review and gate state visible and optionally controlled from Workbench, without allowing provider self-approval or automatic release readiness.

The review/gate path should use explicit operator confirmation and stable plan hashes.

Expected path:

```text
provider worker result
-> v51 result intake
-> v50 event confirm for worker evidence
-> reviewer task pack
-> provider/human reviewer result
-> review/gate readiness
-> review/gate preview
-> operator confirm
-> review/gate event append through controlled command path
```

## Boundary Decision

v57 may add a controlled review/gate surface. It may not infer approval from a provider result or auto-approve a provider's own work.

Allowed:

- review/gate readiness projection;
- provider separation checks;
- review/gate preview;
- planHash confirmation for review/gate events if backed by existing safe command handlers;
- copy-only CLI commands if confirm is not safe enough.

Forbidden:

- auto approval;
- same-provider self-review without explicit human override;
- release/tag automation;
- main/release readiness inference from file names, branch names, or provider text;
- bypassing tests/evidence.

## Global Forbidden Scope

This version must not add or imply:

- provider names outside `codex` and `claude-code`;
- generic shell or terminal UI;
- arbitrary renderer-side command execution;
- frontend reads of local JSONL/session files, provider transcript folders, `.symphony` internals, goal ledgers, or event logs;
- raw transcript or raw model output exposure in Workbench;
- direct goal event append from provider or child output;
- direct task completion from provider output;
- automatic self-review;
- git write, merge, push, tag, publish, GitHub Release creation, or release automation;
- signed distribution, notarization, auto-update, or public `.dmg` claims unless this version explicitly proves them.

## Contracts

Add:

```text
reviewGateReadiness.v1
reviewPlanPreview.v1
gatePlanPreview.v1
reviewGateConfirmation.v1
providerSeparationCheck.v1
manualOverrideReason.v1
```

`reviewGateReadiness.v1` should show:

```text
workerEvidenceState
reviewerEvidenceState
providerSeparationState
requiredCommands[]
missingEvidence[]
eligibleActions[]
blockedReasons[]
```

## Workbench Surface

Allowed labels:

```text
Review / Gate Readiness
Preview Review Plan
Confirm Review Event
Preview Gate Plan
Confirm Gate Event
Copy Review Command
Copy Gate Command
Refresh State
```

If implementation cannot safely open confirm in Workbench, keep confirm as copy-only CLI and record why.

Forbidden labels:

```text
Auto Approve
Auto Pass
Release Now
Publish
Tag
Self Review
```

## PR Breakdown

### PR-0: Runbook

Add this runbook only.

### PR-1: Contracts And Provider Separation Tests

Tests:

```sh
node --test tests/v57-review-gate-workbench-surface.test.js
```

Required cases:

- Codex worker + Claude Code reviewer accepted;
- Claude Code worker + Codex reviewer accepted;
- same-provider review blocked;
- human override requires reason;
- missing evidence blocks gate.

### PR-2: Backend Readiness Projection

Scope:

- read worker/reviewer pending results and confirmed event state;
- project review/gate readiness;
- no verdict inference.

### PR-3: Review/Gate Preview And Confirm

Scope:

- preview commands/events;
- require planHash on confirm;
- use existing safe command handlers;
- never publish/tag/release.

### PR-4: Workbench Review/Gate Surface

Scope:

- render readiness;
- render provider separation;
- render preview/confirm or copy-only commands;
- assert forbidden labels absent.

### PR-5: Acceptance And v58 Handoff

Acceptance should prove one review/gate flow with provider separation and one blocked same-provider flow.

## Acceptance Path

1. Use Codex worker evidence.
2. Use Claude Code reviewer evidence.
3. Preview review event.
4. Confirm review event with planHash or copy CLI command if confirm remains disabled.
5. Preview main gate readiness.
6. Confirm gate event only when required evidence exists.
7. Attempt same-provider review and verify blocked state.
8. Verify no tag/release/publish is available.

## Validation Commands

```sh
pnpm workbench:build
node --test tests/v57-review-gate-workbench-surface.test.js
node --test tests/v55-provider-policy.test.js
node --test tests/v51-result-intake-evidence-escrow.test.js
node --test tests/v50-supervisor-event-registration-eligibility.test.js
node --test tests/workbench-api-client.test.js tests/workbench-shell.test.js tests/workbench-route-smoke.test.js
pnpm check
git diff --check
```

Run `pnpm test` if review/gate command handlers or goal event command paths change.

## Rollback Path

If Workbench confirm mutates the wrong event family, revert PR-3/PR-4 and keep copy-only CLI commands.

If provider separation is bypassed, revert PR-1/PR-2.

## v58 Handoff

v58 should focus on local Mac app packaging evidence. It should not add more workflow mutation.
