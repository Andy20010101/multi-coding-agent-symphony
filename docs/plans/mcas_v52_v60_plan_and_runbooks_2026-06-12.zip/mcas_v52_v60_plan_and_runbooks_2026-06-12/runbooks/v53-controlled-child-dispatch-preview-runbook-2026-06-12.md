# v53 Controlled Child Dispatch Preview Runbook

Date: 2026-06-12  
Timezone: Asia/Shanghai  
Goal id: `v53-controlled-child-dispatch-preview`  
Branch draft: `codex/v53-controlled-child-dispatch-preview`  
Baseline: v52 `system-golden-path-closeout` merged, tagged, and accepted.  
Supported providers: `codex`, `claude-code` only.

## Objective

v53 introduces controlled child task planning without executing providers.

It should create standardized task packs for a future worker/reviewer child and make them copyable for Codex or Claude Code. The system still does not launch either provider in v53.

Expected path:

```text
Supervisor next action
-> Child Dispatch Preview
-> childTaskPack.v1
-> operator copies pack to Codex or Claude Code manually
-> external result returns through v51 Result Intake
```

## Product Problem

Before provider execution is safe, the system needs a stable shape for child work. v53 answers:

```text
What exactly should the child agent receive?
Which role is it playing?
Which evidence is required?
Which files/contracts are in scope?
What result shape must come back to v51?
```

## Boundary Decision

v53 may prepare work. It may not perform work.

Allowed:

- preview child task packs;
- recommend provider role using only `codex` and `claude-code`;
- generate copy-only prompts;
- define expected result blocks for v51 result intake;
- display dispatch readiness.

Forbidden:

- starting Codex;
- starting Claude Code;
- launching a provider from Workbench;
- creating worktrees automatically unless a separate controlled workspace contract is added and explicitly accepted;
- writing goal event state;
- marking task completion.

## Global Forbidden Scope

This version must not add or imply:

- provider names outside `codex` and `claude-code`;
- generic shell or terminal UI;
- arbitrary renderer-side command execution;
- frontend reads of local JSONL/session files, provider transcript folders, `.symphony` internals, goal ledgers, or event logs;
- raw transcript or raw model output exposure in Workbench;
- direct goal event append from provider or child output;
- direct task completion from provider output;
- automatic self-review;
- git write, merge, push, tag, publish, GitHub Release creation, or release automation;
- signed distribution, notarization, auto-update, or public `.dmg` claims unless this version explicitly proves them.

## Contracts

Add:

```text
childDispatchRequest.v1
childDispatchPreview.v1
childTaskPack.v1
childResultExpectation.v1
providerRoleRecommendation.v1
```

`providerRoleRecommendation.v1` must restrict provider ids to:

```text
codex
claude-code
```

`childTaskPack.v1` should include:

```text
goalId
taskId
role: worker | reviewer | blocker-investigator | verifier
preferredProvider
allowedProviders[]
projectContextRefs[]
sourceContracts[]
taskPrompt
acceptanceCriteria[]
requiredEvidenceRefs[]
forbiddenActions[]
expectedResultBlock
returnPath: v51-result-intake
```

## Workbench Surface

Add a controlled preview/copy lane.

Allowed labels:

```text
Preview Child Task
Copy Child Task Pack
Copy Codex Task Pack
Copy Claude Code Task Pack
Refresh State
```

Forbidden labels:

```text
Dispatch Child
Run Child
Launch Codex
Launch Claude Code
Execute
```

## PR Breakdown

### PR-0: Runbook

Add this runbook only.

Validation:

```sh
git diff --check
git diff --cached --check
```

### PR-1: Contracts, Fixtures, Tests

Fixtures:

```text
child-dispatch-preview.codex-worker.v1.json
child-dispatch-preview.claude-reviewer.v1.json
child-dispatch-preview.blocked-missing-goal.v1.json
child-dispatch-preview.blocked-unsupported-provider.v1.json
child-task-pack.worker.v1.json
child-task-pack.reviewer.v1.json
```

Tests:

```sh
node --test tests/v53-child-dispatch-preview.test.js
```

### PR-2: Backend Preview Projection

Scope:

- build preview from active goal, next action, supervisor, Golden Path, and provider policy;
- produce no writes;
- reject unsupported provider ids;
- preserve source contract refs.

Validation:

```sh
node --test tests/v53-child-dispatch-preview.test.js tests/v52-system-golden-path.test.js
pnpm check
git diff --check
```

### PR-3: Workbench Preview Lane

Scope:

- render child task preview;
- render copy-only task pack;
- show expected result shape for v51 intake;
- assert no execution controls.

Validation:

```sh
pnpm workbench:build
node --test tests/workbench-api-client.test.js tests/workbench-shell.test.js tests/workbench-route-smoke.test.js
node --test tests/v53-child-dispatch-preview.test.js
pnpm check
git diff --check
```

### PR-4: Acceptance Evidence

Acceptance should use two fake paths:

```text
Codex worker task pack
Claude Code reviewer task pack
```

Both should return through a fake v51 result block shape without execution.

### PR-5: Closeout And v54 Handoff

Closeout should hand v54 to a narrow Codex provider execution pilot.

## Acceptance Path

1. Open Workbench.
2. Confirm v52 Golden Path is readable.
3. Preview a Codex worker task pack.
4. Verify the task pack says result must return through v51 result intake.
5. Preview a Claude Code reviewer task pack.
6. Verify provider separation is visible.
7. Copy both task packs.
8. Confirm no provider starts and no goal event is appended.
9. Confirm unsupported provider id is blocked.
10. Confirm acceptance docs record command/test evidence.

## Validation Commands

```sh
pnpm workbench:build
node --test tests/v53-child-dispatch-preview.test.js
node --test tests/v52-system-golden-path.test.js
node --test tests/v51-result-intake-evidence-escrow.test.js
node --test tests/workbench-api-client.test.js tests/workbench-shell.test.js tests/workbench-route-smoke.test.js
pnpm check
git diff --check
```

## Rollback Path

If child task packs are ambiguous or imply execution, revert PR-2/PR-3.

If provider recommendation leaks unsupported providers, revert the provider policy portion and keep manual copy-only packs.

## v54 Handoff

v54 should add a narrow Codex provider execution pilot using `childTaskPack.v1` as input and v51 result intake as output. It should not add Claude Code execution yet.
