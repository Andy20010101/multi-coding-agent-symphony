# v55 Claude Code Provider Parity And Result Return Runbook

Date: 2026-06-12  
Timezone: Asia/Shanghai  
Goal id: `v55-claude-code-provider-parity-result-return`  
Branch draft: `codex/v55-claude-code-provider-parity-result-return`  
Baseline: v54 `codex-provider-execution-pilot` merged, tagged, and accepted.  
Supported providers: `codex`, `claude-code` only.

## Objective

v55 adds Claude Code as the second and final supported provider and normalizes provider result return across Codex and Claude Code.

Expected path:

```text
childTaskPack.v1
-> provider execution preview
-> operator confirm
-> Codex or Claude Code fixed command envelope
-> providerExecutionResult.v1
-> common provider result return
-> v51 result intake
-> pendingResult.v1
```

## Boundary Decision

v55 authorizes Claude Code under the same controlled execution architecture as Codex. It does not add a third provider, arbitrary provider config, or Workbench release automation.

Allowed:

- Claude Code help/smoke detection;
- fixed Claude Code command envelope;
- provider capability matrix for Codex and Claude Code only;
- shared provider result shape;
- provider role assignment checks;
- result return into v51.

Forbidden:

- unsupported providers;
- arbitrary Claude Code args;
- renderer-side command text;
- provider self-review;
- direct goal event append;
- release automation.

## Global Forbidden Scope

This version must not add or imply:

- provider names outside `codex` and `claude-code`;
- generic shell or terminal UI;
- arbitrary renderer-side command execution;
- frontend reads of local JSONL/session files, provider transcript folders, `.symphony` internals, goal ledgers, or event logs;
- raw transcript or raw model output exposure in Workbench;
- direct goal event append from provider or child output;
- direct task completion from provider output;
- automatic self-review;
- git write, merge, push, tag, publish, GitHub Release creation, or release automation;
- signed distribution, notarization, auto-update, or public `.dmg` claims unless this version explicitly proves them.

## Contracts

Add or extend:

```text
providerCapabilityMatrix.v1
providerExecutionPolicy.v1
providerExecutionPreview.v1
providerExecutionResult.v1
providerResultReturn.v1
providerRoleAssignment.v1
providerSeparationCheck.v1
```

`providerCapabilityMatrix.v1` must include exactly:

```text
codex
claude-code
```

Unsupported provider ids must fail closed.

## Provider Separation

If a Codex task produces a worker result, Claude Code should be the preferred reviewer provider. If Claude Code produces a worker result, Codex should be the preferred reviewer provider.

`providerSeparationCheck.v1` should expose:

```text
workerProvider
reviewerProvider
state: satisfied | missing | same-provider-blocked | human-override-required
blockedReasons[]
```

## Workbench Surface

Allowed controls:

```text
Preview Provider Execution
Confirm Codex Execution
Confirm Claude Code Execution
Refresh Provider Result
Return Result To Intake
```

The UI must show provider id, role, command shape id, result return path, and provider separation warning.

Forbidden controls:

```text
Custom Provider
Add Provider
Run Shell
Terminal
Auto Review
Auto Approve
```

## PR Breakdown

### PR-0: Runbook

Add this runbook only.

### PR-1: Provider Matrix And Policy

Scope:

- add provider matrix with Codex and Claude Code only;
- tests reject unsupported provider ids;
- docs update provider scope.

Tests:

```sh
node --test tests/v55-provider-policy.test.js
```

### PR-2: Claude Code Command Envelope

Scope:

- fixed Claude Code command shape;
- no arbitrary args;
- planHash confirm;
- deterministic fake runner fallback.

Tests:

```sh
node --test tests/v55-claude-code-provider-parity.test.js
```

### PR-3: Shared Result Return

Scope:

- normalize Codex and Claude Code result shapes;
- return both through v51 intake;
- preserve provider separation fields.

### PR-4: Workbench Provider Parity Surface

Scope:

- show Codex and Claude Code as the only providers;
- show provider result return;
- show separation warning;
- refresh assets.

### PR-5: Acceptance And v56 Handoff

Acceptance should prove:

- Codex provider path still works;
- Claude Code provider path works or fake-runner fallback is documented;
- unsupported provider id is blocked;
- result return enters v51;
- no provider directly writes goal events.

## Validation Commands

```sh
pnpm workbench:build
node --test tests/v55-provider-policy.test.js
node --test tests/v55-claude-code-provider-parity.test.js
node --test tests/v54-codex-provider-execution-pilot.test.js
node --test tests/v51-result-intake-evidence-escrow.test.js
node --test tests/workbench-api-client.test.js tests/workbench-shell.test.js tests/workbench-route-smoke.test.js
pnpm check
git diff --check
```

Optional provider checks:

```sh
pnpm smoke:codex:help
pnpm smoke:claude:help
```

Real provider runs must be opt-in.

## Rollback Path

If Claude Code envelope is unsafe, revert PR-2/PR-3 and keep Codex-only execution from v54.

If provider matrix admits unsupported providers, revert PR-1.

## v56 Handoff

v56 should create provider-specific thread continuation and handoff packs for Codex and Claude Code. It should not automatically compact or create threads.
