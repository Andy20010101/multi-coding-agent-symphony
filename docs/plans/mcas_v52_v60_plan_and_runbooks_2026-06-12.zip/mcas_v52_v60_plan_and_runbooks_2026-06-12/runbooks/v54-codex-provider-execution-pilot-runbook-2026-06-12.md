# v54 Codex Provider Execution Pilot Runbook

Date: 2026-06-12  
Timezone: Asia/Shanghai  
Goal id: `v54-codex-provider-execution-pilot`  
Branch draft: `codex/v54-codex-provider-execution-pilot`  
Baseline: v53 `controlled-child-dispatch-preview` merged, tagged, and accepted.  
Supported providers: `codex`, `claude-code` only.

## Objective

v54 is the first controlled provider execution version. It should support only Codex, only through a fixed command envelope, only from a validated child task pack, and only with provider results returning to v51 result intake.

Expected path:

```text
childTaskPack.v1
-> Codex provider execution preview
-> operator confirm
-> fixed Codex command envelope
-> controlled workspace
-> providerExecutionResult.v1
-> v51 result intake preview/confirm
-> pendingResult.v1
-> v50 event preview/confirm
```

## Boundary Decision

v54 authorizes a narrow Codex execution pilot. It does not authorize arbitrary commands, arbitrary provider options, Claude Code execution, multi-agent execution, or direct goal event writes.

Allowed:

- Codex help/smoke detection;
- backend-owned fixed Codex command envelope;
- controlled workspace lease;
- execution preview;
- execution confirm;
- result capture;
- sanitized providerExecutionResult;
- handoff to v51 result intake.

Forbidden:

- Claude Code execution in v54;
- arbitrary `codex` args from user input;
- renderer-side command construction;
- shell fragments;
- direct goal event append;
- task completion without v51/v50 chain;
- provider self-review.

## Global Forbidden Scope

This version must not add or imply:

- provider names outside `codex` and `claude-code`;
- generic shell or terminal UI;
- arbitrary renderer-side command execution;
- frontend reads of local JSONL/session files, provider transcript folders, `.symphony` internals, goal ledgers, or event logs;
- raw transcript or raw model output exposure in Workbench;
- direct goal event append from provider or child output;
- direct task completion from provider output;
- automatic self-review;
- git write, merge, push, tag, publish, GitHub Release creation, or release automation;
- signed distribution, notarization, auto-update, or public `.dmg` claims unless this version explicitly proves them.

## Contracts

Add or extend:

```text
providerExecutionPreview.v1
providerExecutionConfirm.v1
providerCommandEnvelope.v1
providerWorkspaceLease.v1
providerExecutionResult.v1
providerExecutionBoundary.v1
```

`providerCommandEnvelope.v1` required fields:

```text
providerId: codex
commandShapeId
workingDirectoryRef
inputTaskPackRef
allowedEnvironmentKeys[]
timeoutPolicy
outputCapturePolicy
artifactCapturePolicy
forbiddenArgs[]
willMutateWorkspace
willWriteGoalState: false
returnPath: v51-result-intake
```

## Codex Command Boundary

Codex command execution must be backend-owned. The renderer may request preview/confirm by opaque ids and plan hashes. The renderer must not submit raw command text, executable paths, local file paths, provider flags, shell snippets, or model options.

## Workbench Surface

Allowed controls for this version:

```text
Preview Codex Execution
Confirm Codex Execution
Refresh Provider Result
Send Result To Intake
```

Forbidden labels:

```text
Run Agent
Shell
Terminal
Custom Command
Launch Claude Code
Dispatch Any Provider
```

`Send Result To Intake` may only call the v51 result intake preview/confirm path or display the v51 next step. It must not append goal events.

## PR Breakdown

### PR-0: Runbook

Add this runbook only.

### PR-1: Contracts And Fixtures

Fixtures:

```text
provider-execution-preview.codex-safe.v1.json
provider-execution-preview.codex-blocked-unsupported-arg.v1.json
provider-execution-result.codex-success.v1.json
provider-execution-result.codex-failed.v1.json
provider-workspace-lease.safe.v1.json
```

Tests:

```sh
node --test tests/v54-codex-provider-execution-pilot.test.js
```

### PR-2: Backend Codex Preview

Scope:

- validate `childTaskPack.v1`;
- produce fixed command envelope;
- no execution;
- no workspace mutation.

### PR-3: Backend Codex Confirm And Result Capture

Scope:

- confirm requires preview planHash;
- execute fixed envelope only;
- capture stdout/stderr safely;
- produce `providerExecutionResult.v1`;
- do not append goal events;
- send/prepare result for v51 intake.

### PR-4: Workbench Codex Pilot Lane

Scope:

- show preview, confirm, result summary, and v51 intake handoff;
- assert no generic command controls;
- refresh Workbench assets.

### PR-5: Acceptance And Closeout

Acceptance should include:

- Codex help/smoke available or clearly skipped with reason;
- one controlled fake or real Codex pilot;
- provider result enters v51 intake;
- pending result becomes eligible for v50 event preview;
- no direct goal event append.

## Validation Commands

```sh
pnpm workbench:build
node --test tests/v54-codex-provider-execution-pilot.test.js
node --test tests/v53-child-dispatch-preview.test.js
node --test tests/v51-result-intake-evidence-escrow.test.js
node --test tests/v50-supervisor-event-registration-eligibility.test.js
node --test tests/workbench-api-client.test.js tests/workbench-shell.test.js tests/workbench-route-smoke.test.js
pnpm check
git diff --check
```

Optional local provider check:

```sh
pnpm smoke:codex:help
```

Real Codex execution must be opt-in and recorded in acceptance evidence. If credentials/model access are missing, the PR may use a deterministic fake provider runner but must not claim real Codex execution.

## Rollback Path

If command envelope validation is unsafe, revert PR-2/PR-3 and keep v53 copy-only task packs.

If Workbench makes Codex execution look generic, revert PR-4.

## v55 Handoff

v55 should add Claude Code provider parity under the same provider execution contract and prove shared result return for Codex and Claude Code.
