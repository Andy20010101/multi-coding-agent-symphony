# v60 Stable Personal Workbench Release Runbook

Date: 2026-06-12  
Timezone: Asia/Shanghai  
Goal id: `v60-stable-personal-workbench-release`  
Branch draft: `codex/v60-stable-personal-workbench-release`  
Baseline: v59 `dual-provider-multi-agent-e2e` merged, tagged, and accepted.  
Supported providers: `codex`, `claude-code` only.

## Objective

v60 is the stable personal Workbench baseline. It should not be a feature sprint. It should consolidate v47-v59 into a documented, tested, daily-usable personal app/workbench.

By v60, the product should honestly claim:

```text
multi-coding-agent-symphony is a local personal Workbench for supervised Codex and Claude Code development workflows.
It supports project selection, goal supervision, context advisory, result intake, controlled event registration, child task planning, controlled provider execution, provider-separated review/gate flow, thread handoff packs, local app shell evidence, and dual-provider E2E evidence.
```

## Product Completion Criteria

v60 is complete when the operator can use the system for a real daily development loop:

```text
Open Workbench / local app
-> select project
-> inspect goal and supervisor state
-> preview child task
-> execute Codex or Claude Code under controlled provider contracts
-> return result to intake
-> confirm event through planHash
-> review with provider separation
-> gate/closeout with evidence
-> generate thread handoff if needed
-> prepare next version runbook
```

## Boundary Decision

v60 may prepare a stable tag and release notes. It may not automate publish/tag/release from Workbench.

Allowed:

- docs synchronization;
- operator guide updates;
- recovery guide;
- provider guide;
- security/boundary checklist;
- stable release evidence;
- manual tag/release prep notes;
- one final E2E smoke.

Forbidden:

- new provider integrations;
- new generic execution surfaces;
- release automation;
- auto-update/public distribution claims without proof.

## Global Forbidden Scope

This version must not add or imply:

- provider names outside `codex` and `claude-code`;
- generic shell or terminal UI;
- arbitrary renderer-side command execution;
- frontend reads of local JSONL/session files, provider transcript folders, `.symphony` internals, goal ledgers, or event logs;
- raw transcript or raw model output exposure in Workbench;
- direct goal event append from provider or child output;
- direct task completion from provider output;
- automatic self-review;
- git write, merge, push, tag, publish, GitHub Release creation, or release automation;
- signed distribution, notarization, auto-update, or public `.dmg` claims unless this version explicitly proves them.

## Stable Baseline Documents

Update or create:

```text
README.md
docs/workbench-operator-guide.md
docs/release-checklist.md
docs/security-checklist.md
docs/troubleshooting.md
docs/provider-boundary-guide.md
docs/daily-workflow-runbook.md
docs/recovery-guide.md
docs/plans/v60-stable-personal-workbench-release-evidence-2026-06-12.md
docs/plans/v60-stable-personal-workbench-closeout-snapshot-2026-06-12.md
```

README should include:

```text
Current tagged release
Current app entry
Supported providers: Codex and Claude Code
Daily workflow
What is automated
What remains operator-controlled
Known limitations
```

## Stable Workbench Feature Matrix

v60 should document the final state:

| Area | v60 expectation |
| --- | --- |
| Project entry | Project Launcher / current binding / health |
| Goal supervision | Active goal, next action, supervisor status |
| Context | Advisory and handoff packs |
| Result intake | Preview/confirm evidence escrow |
| Event registration | Controlled preview/planHash confirm |
| Child task planning | Preview and copy task packs |
| Provider execution | Controlled Codex and Claude Code |
| Review/gate | Provider separation and explicit confirmation/copy-only fallback |
| Desktop | Local app shell/bundle evidence |
| E2E | Dual-provider evidence |
| Release | Manual release manager action, no Workbench automation |

## PR Breakdown

### PR-0: v60 Runbook

Add this runbook only.

### PR-1: Documentation Synchronization

Scope:

- README current state;
- operator guide;
- provider guide;
- daily workflow;
- recovery guide.

### PR-2: Stable Acceptance Matrix

Add `stableWorkbenchRelease.v1` and fixtures:

```text
stable-workbench-release.ready.v1.json
stable-workbench-release.blocked-provider-missing.v1.json
stable-workbench-release.blocked-e2e-missing.v1.json
stable-workbench-release.local-app-limited.v1.json
```

Tests:

```sh
node --test tests/v60-stable-personal-workbench-release.test.js
```

### PR-3: Final Workbench Polish

Scope:

- no new feature surfaces;
- align status labels;
- ensure Golden Path, provider status, handoff, review/gate, and E2E evidence are findable;
- refresh assets only if source changes.

### PR-4: Full Acceptance Evidence

Evidence should include:

- v52 Golden Path;
- v53 child preview;
- v54 Codex execution;
- v55 Claude Code parity;
- v56 handoff pack;
- v57 review/gate;
- v58 local app evidence;
- v59 E2E run;
- raw transcript exclusion;
- unsupported provider blocking;
- no release automation.

### PR-5: Closeout, Tag Prep, Release Notes

Files:

```text
docs/plans/v60-stable-personal-workbench-closeout-snapshot-2026-06-12.md
docs/plans/v60-stable-personal-workbench-release-prep-2026-06-12.md
```

Release note draft should avoid overclaims:

```text
v60: Stable Personal Workbench Baseline

- Supports local supervised workflows for Codex and Claude Code.
- Provides Project Launcher, App Home, Supervisor, Context Advisory, Result Intake, Event Registration, Child Task Planning, controlled provider execution, review/gate evidence, thread handoff packs, local app evidence, and dual-provider E2E evidence.
- Keeps provider results behind result intake and event planHash confirmation.
- Keeps release/tag/publish actions manual.
- Does not claim public distribution, notarization, auto-update, or generic shell execution.
```

## Acceptance Path

1. Start from clean main.
2. Build Workbench.
3. Launch local app path or documented local app evidence path.
4. Select project.
5. Complete Golden Path readiness check.
6. Preview child task.
7. Execute one Codex task or deterministic accepted fallback.
8. Execute one Claude Code task/review or deterministic accepted fallback.
9. Return results through v51 intake.
10. Confirm worker event through v50.
11. Review/gate through v57.
12. Generate v56 thread handoff pack.
13. Close out goal/version.
14. Verify README/operator guide reflect current reality.
15. Verify no unsupported provider, generic shell, raw transcript exposure, or release automation.

## Validation Commands

```sh
pnpm workbench:build
node --test tests/v60-stable-personal-workbench-release.test.js
node --test tests/v59-dual-provider-multi-agent-e2e.test.js
node --test tests/v57-review-gate-workbench-surface.test.js
node --test tests/v56-thread-continuation-handoff-pack.test.js
node --test tests/v55-provider-policy.test.js
node --test tests/v54-codex-provider-execution-pilot.test.js
node --test tests/v53-child-dispatch-preview.test.js
node --test tests/v52-system-golden-path.test.js
node --test tests/v51-result-intake-evidence-escrow.test.js
node --test tests/v50-supervisor-event-registration-eligibility.test.js
node --test tests/workbench-api-client.test.js tests/workbench-shell.test.js tests/workbench-route-smoke.test.js
pnpm desktop:shell:smoke
pnpm check
git diff --check
```

Run:

```sh
pnpm test
```

before tagging unless closeout explicitly records why it was not selected.

Optional provider checks:

```sh
pnpm smoke:codex:help
pnpm smoke:claude:help
```

## Rollback Path

If docs overstate current behavior, revert PR-1 or PR-5 docs only.

If final Workbench polish changes behavior, revert PR-3 and keep the v59 UI.

If v60 acceptance fails, do not tag. Create a v60.1 stabilization runbook instead.

## Post-v60 Handoff

Post-v60 work should be maintenance and polish first:

```text
v60.1 stabilization fixes
v61 signed/notarized distribution research
v62 advanced provider scheduling
v63 multi-project dashboard
```

Do not add new providers until the Codex/Claude Code baseline remains stable across repeated daily runs.
