# v58 Local Mac App Bundle Packaging Evidence Runbook

Date: 2026-06-12  
Timezone: Asia/Shanghai  
Goal id: `v58-local-mac-app-bundle-packaging-evidence`  
Branch draft: `codex/v58-local-mac-app-bundle-packaging-evidence`  
Baseline: v57 `review-gate-workbench-surface` merged, tagged, and accepted.  
Supported providers: `codex`, `claude-code` only.

## Objective

v58 makes the local Mac app path credible. It should produce local packaging evidence for the Tauri shell and Workbench entry without claiming signed public distribution.

The target is:

```text
local Mac app bundle
-> app launches
-> sidecar/backend state visible
-> Workbench daily path visible
-> provider execution still backend-controlled
-> no generic shell or arbitrary renderer command path
```

## Boundary Decision

v58 is packaging evidence, not public distribution.

Allowed:

- local app build or bundle smoke;
- Tauri boundary hardening;
- app launch health projection;
- desktop smoke tests;
- packaging docs;
- local operator instructions.

Forbidden:

- signed distribution claim;
- notarization claim;
- auto-update;
- public `.dmg` claim unless actually built and documented as unsigned/local;
- provider execution changes;
- release automation.

## Global Forbidden Scope

This version must not add or imply:

- provider names outside `codex` and `claude-code`;
- generic shell or terminal UI;
- arbitrary renderer-side command execution;
- frontend reads of local JSONL/session files, provider transcript folders, `.symphony` internals, goal ledgers, or event logs;
- raw transcript or raw model output exposure in Workbench;
- direct goal event append from provider or child output;
- direct task completion from provider output;
- automatic self-review;
- git write, merge, push, tag, publish, GitHub Release creation, or release automation;
- signed distribution, notarization, auto-update, or public `.dmg` claims unless this version explicitly proves them.

## Contracts / Evidence

Add:

```text
desktopBundleEvidence.v1
appLaunchHealth.v1
desktopBoundarySmoke.v1
sidecarLaunchEvidence.v1
```

Evidence should record:

```text
build command
platform
bundle path if generated
app launch result
sidecar state
backend route state
forbidden command surface checks
known limitations
```

## PR Breakdown

### PR-0: Runbook

Add this runbook only.

### PR-1: Packaging Docs And Current App Shape

Update:

```text
desktop/shell/README.md
docs/workbench-operator-guide.md
docs/release-checklist.md
```

Make the distinction clear:

```text
local app bundle evidence != signed distribution
```

### PR-2: Desktop Boundary Smoke Hardening

Scope:

- assert native command surface remains fixed;
- assert no generic shell;
- assert no provider command from renderer.

Validation:

```sh
pnpm desktop:shell:smoke
cargo check --manifest-path desktop/shell/src-tauri/Cargo.toml --target-dir tmp/tauri-target
```

### PR-3: Local Bundle Build Evidence

Scope:

- inspect existing Tauri config and package scripts;
- run the safest local build/bundle command available in the repo;
- record exact command and output;
- do not invent `.dmg`, notarization, signing, or auto-update claims.

If full bundle build is unavailable, record why and keep v58 as boundary evidence with a follow-up.

### PR-4: Workbench/App Launch Evidence

Scope:

- confirm app route loads;
- confirm daily path panels render;
- confirm provider execution remains backend-owned;
- confirm no browser URL error is the primary failure state.

### PR-5: Closeout And v59 Handoff

Closeout should hand v59 to dual-provider multi-agent E2E.

## Acceptance Path

1. Build Workbench.
2. Run desktop shell smoke.
3. Run Tauri compile check.
4. Run local bundle/build command if available.
5. Launch local app or record launch-equivalent route evidence.
6. Verify sidecar/backend/project/supervisor state is visible.
7. Verify no generic shell, terminal, arbitrary command, tag, release, publish, or update controls exist.
8. Record local packaging limitations honestly.

## Validation Commands

```sh
pnpm workbench:build
pnpm desktop:shell:smoke
cargo check --manifest-path desktop/shell/src-tauri/Cargo.toml --target-dir tmp/tauri-target
node --test tests/workbench-api-client.test.js tests/workbench-shell.test.js tests/workbench-route-smoke.test.js
pnpm check
git diff --check
```

Run the actual Tauri bundle/build command only after inspecting `desktop/shell/README.md`, `desktop/shell/src-tauri/tauri.conf.json`, and package scripts.

## Rollback Path

If packaging docs overstate distribution support, revert PR-1/PR-3 docs.

If desktop boundary smoke blocks legitimate app launch, fix the smoke assertion narrowly. Do not open generic shell or renderer command execution.

## v59 Handoff

v59 should perform a controlled dual-provider multi-agent E2E run using Codex and Claude Code.
