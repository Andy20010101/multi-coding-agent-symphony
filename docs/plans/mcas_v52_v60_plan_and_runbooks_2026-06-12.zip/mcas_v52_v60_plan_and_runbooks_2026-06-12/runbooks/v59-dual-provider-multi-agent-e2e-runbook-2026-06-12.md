# v59 Dual Provider Multi Agent E2E Runbook

Date: 2026-06-12  
Timezone: Asia/Shanghai  
Goal id: `v59-dual-provider-multi-agent-e2e`  
Branch draft: `codex/v59-dual-provider-multi-agent-e2e`  
Baseline: v58 `local-mac-app-bundle-packaging-evidence` merged, tagged, and accepted.  
Supported providers: `codex`, `claude-code` only.

## Objective

v59 proves the complete controlled multi-agent loop with the only two supported providers: Codex and Claude Code.

At least one path should run end-to-end:

```text
Goal
-> Supervisor
-> Child Task Preview
-> Codex worker execution
-> v51 Result Intake
-> v50 Event Preview / Confirm
-> Claude Code reviewer execution or reviewer task pack
-> Review/Gate Readiness
-> Review/Gate Confirm or copy-only command
-> Closeout
```

A second mirrored path is recommended if provider access and cost allow:

```text
Claude Code worker
-> Codex reviewer
```

## Boundary Decision

v59 is the first full dual-provider proof. It must prioritize safety, traceability, and provider separation over speed.

Allowed:

- real Codex execution if available;
- real Claude Code execution if available;
- deterministic fake provider fallback only when real provider is unavailable and clearly recorded;
- provider separation evidence;
- full evidence chain through v51/v50/v57;
- closeout evidence.

Forbidden:

- unsupported providers;
- same-provider self-review without human override;
- direct provider-to-event append;
- release/tag/publish automation;
- public distribution claims.

## Global Forbidden Scope

This version must not add or imply:

- provider names outside `codex` and `claude-code`;
- generic shell or terminal UI;
- arbitrary renderer-side command execution;
- frontend reads of local JSONL/session files, provider transcript folders, `.symphony` internals, goal ledgers, or event logs;
- raw transcript or raw model output exposure in Workbench;
- direct goal event append from provider or child output;
- direct task completion from provider output;
- automatic self-review;
- git write, merge, push, tag, publish, GitHub Release creation, or release automation;
- signed distribution, notarization, auto-update, or public `.dmg` claims unless this version explicitly proves them.

## Contracts

Add:

```text
multiAgentRunPlan.v1
providerRoleAssignment.v1
multiAgentRunEvidence.v1
agentSeparationProof.v1
e2eFailureMode.v1
```

`multiAgentRunEvidence.v1` should include:

```text
goalId
runId
workerProvider
reviewerProvider
childTaskPackRefs[]
providerExecutionRefs[]
resultIntakeRefs[]
eventConfirmationRefs[]
reviewGateRefs[]
closeoutRefs[]
blockedOrSkippedReasons[]
costOrUsageRecord
```

## PR Breakdown

### PR-0: Runbook

Add this runbook only.

### PR-1: E2E Contracts And Fixtures

Tests:

```sh
node --test tests/v59-dual-provider-multi-agent-e2e.test.js
```

### PR-2: E2E Orchestration Dry Run

Scope:

- assemble full path without real provider execution;
- validate refs and provider separation;
- no writes except dry-run artifacts if explicitly allowed.

### PR-3: Real/Fake Provider E2E Execution

Scope:

- run Codex worker path;
- run Claude Code reviewer path if credentials available;
- otherwise use deterministic fake with explicit skip reason;
- result must return through v51.

### PR-4: Workbench E2E Evidence Panel

Scope:

- show run plan, provider roles, refs, blocked reasons, and closeout readiness;
- no release controls.

### PR-5: Acceptance And v60 Handoff

Acceptance should include:

- one completed E2E path;
- one blocked/failed path if provider unavailable;
- provider separation proof;
- raw transcript exclusion;
- no direct goal event append from provider.

## Acceptance Path

1. Pick a small safe goal.
2. Generate child task pack.
3. Execute Codex worker or fake provider with explicit reason.
4. Return result through v51 intake.
5. Confirm worker event through v50 preview/confirm.
6. Generate Claude Code reviewer task or execute Claude Code reviewer if available.
7. Confirm review/gate through v57 path or copy-only CLI.
8. Close out the goal.
9. Record evidence refs.
10. Prove unsupported provider and same-provider self-review are blocked.

## Validation Commands

```sh
pnpm workbench:build
node --test tests/v59-dual-provider-multi-agent-e2e.test.js
node --test tests/v57-review-gate-workbench-surface.test.js
node --test tests/v55-provider-policy.test.js
node --test tests/v54-codex-provider-execution-pilot.test.js
node --test tests/v51-result-intake-evidence-escrow.test.js
node --test tests/workbench-api-client.test.js tests/workbench-shell.test.js tests/workbench-route-smoke.test.js
pnpm check
git diff --check
```

Optional provider checks:

```sh
pnpm smoke:codex:help
pnpm smoke:claude:help
```

Real provider execution must be explicitly recorded.

## Rollback Path

If E2E orchestration bypasses result intake or event confirm, revert PR-2/PR-3.

If Workbench evidence panel implies release automation, revert PR-4.

## v60 Handoff

v60 should stabilize the personal Workbench baseline, synchronize docs, produce operator guides, record known limitations, and prepare a stable release/tag.
