# v52 System Golden Path Closeout Runbook

Date: 2026-06-12  
Timezone: Asia/Shanghai  
Goal id: `v52-system-golden-path-closeout`  
Branch draft: `codex/v52-system-golden-path-closeout`  
Baseline: v51 `result-intake-evidence-escrow` merged, tagged, and accepted.  
Supported providers: `codex`, `claude-code` only.

## Objective

v52 turns v47-v51 into one visible daily Golden Path. It should not add provider execution or child dispatch. It should prove that the operator can open the Workbench, bind the project, inspect supervisor/context/result-intake/event-registration state, and know the next safe action.

The Golden Path is:

```text
Project Launcher
-> App Home
-> Supervisor
-> Context Advisory
-> Result Intake
-> Event Preview / Confirm
-> Review / Gate
-> Closeout
```

## Product Problem

v51 makes external results safe to enter pending result escrow. v50 makes controlled event preview/confirm possible. But the operator still needs one first-class view that answers:

```text
Can this project continue today?
Which step is ready?
Which step is blocked?
Which contract/source proves that state?
What is the next safe action?
```

v52 should answer that question without executing work.

## Boundary Decision

v52 is a read-model and acceptance release. It is allowed to aggregate existing safe contracts. It is not allowed to perform work.

Allowed state changes:

- docs updates;
- generated Workbench assets tied to Workbench source changes;
- new read-only Golden Path projection artifacts if backend-owned;
- acceptance evidence files.

Forbidden state changes:

- provider execution;
- child dispatch;
- result intake confirm beyond the existing v51 route;
- event append beyond the existing v50 route;
- review/gate mutation from the new Golden Path panel.

## Global Forbidden Scope

This version must not add or imply:

- provider names outside `codex` and `claude-code`;
- generic shell or terminal UI;
- arbitrary renderer-side command execution;
- frontend reads of local JSONL/session files, provider transcript folders, `.symphony` internals, goal ledgers, or event logs;
- raw transcript or raw model output exposure in Workbench;
- direct goal event append from provider or child output;
- direct task completion from provider output;
- automatic self-review;
- git write, merge, push, tag, publish, GitHub Release creation, or release automation;
- signed distribution, notarization, auto-update, or public `.dmg` claims unless this version explicitly proves them.

## Contracts And Read Model Direction

Add `systemGoldenPath.v1`.

Required fields:

```text
contractName
contractVersion
generatedAt
project
goal
steps[]
overallState
nextSafeAction
blockedReasons[]
sourceContracts[]
routeProvenance
boundaries
```

Each step should include:

```text
id
label
state: ready | pending | blocked | missing | stale | degraded | manual-required
sourceContract
sourceRef
blockedReasons[]
nextSafeAction
willMutate
```

Required step ids:

```text
project-binding
app-home
supervisor
context-advisory
result-intake
event-preview
event-confirm
review-gate
closeout
```

`review-gate` should default to `manual-required` unless v57 later opens a separate controlled review/gate path.

## Workbench Surface

Add a read-only `System Golden Path` panel to `/workbench/desktop/` or `/workbench/supervisor/`.

Allowed labels:

```text
System Golden Path
Next Safe Action
Source Contract
Blocked Reason
Manual CLI Required
Refresh State
```

Forbidden labels:

```text
Run Agent
Execute
Launch Provider
Dispatch Child
Compact Now
New Thread
Push
Tag
Publish
Release
```

## PR Breakdown

### PR-0: Runbook

Files:

```text
docs/plans/v52-system-golden-path-closeout-runbook-2026-06-12.md
```

Validation:

```sh
git diff --check
git diff --cached --check
```

### PR-1: Provider Scope And Current-State Docs

Scope:

- update README/operator docs that still describe older provider scope;
- make forward provider matrix only `codex` and `claude-code`;
- keep historical release evidence intact;
- add a short current-state section explaining v51 -> v52 direction.

Validation:

```sh
pnpm check
git diff --check
```

### PR-2: `systemGoldenPath.v1` Contracts And Fixtures

Fixtures:

```text
system-golden-path.ready.v1.json
system-golden-path.missing-project.v1.json
system-golden-path.missing-supervisor.v1.json
system-golden-path.result-intake-blocked.v1.json
system-golden-path.event-preview-blocked.v1.json
system-golden-path.review-gate-manual.v1.json
system-golden-path.closeout-gaps.v1.json
```

Tests:

```sh
node --test tests/v52-system-golden-path.test.js
```

### PR-3: Backend/App Read Model Projection

Scope:

- project existing contracts into `systemGoldenPath.v1`;
- preserve missing/stale/degraded state;
- do not infer health from UI render success;
- do not read local files from frontend.

Validation:

```sh
node --test tests/v52-system-golden-path.test.js tests/v44-goal-supervisor-app-read-model.test.js
pnpm check
git diff --check
```

### PR-4: Workbench Panel

Scope:

- render `System Golden Path`;
- show source contracts and blocked reasons;
- refresh generated Workbench assets;
- assert forbidden controls are absent.

Validation:

```sh
pnpm workbench:build
node --test tests/workbench-api-client.test.js tests/workbench-shell.test.js tests/workbench-route-smoke.test.js
node --test tests/v52-system-golden-path.test.js
pnpm check
git diff --check
```

### PR-5: Acceptance And Closeout

Files:

```text
docs/qa/v52-system-golden-path-closeout-acceptance.md
docs/plans/v52-system-golden-path-closeout-snapshot-2026-06-12.md
docs/plans/v53-controlled-child-dispatch-preview-runbook-2026-06-12.md
```

Acceptance must prove the full daily path from project selection through result intake and event registration, while provider execution and child dispatch remain unavailable.

## Acceptance Path

1. Start Workbench.
2. Select/bind the project.
3. Confirm App Home is ready or displays exact degraded/missing state.
4. Confirm Supervisor is readable.
5. Confirm Context Advisory is visible.
6. Confirm Result Intake readiness from v51 is visible.
7. Confirm Event Preview/Confirm readiness from v50 is visible.
8. Confirm Review/Gate displays manual-required or controlled-disabled state.
9. Confirm Closeout readiness/gaps are visible.
10. Confirm no provider execution, child dispatch, terminal, session read, or release automation controls appear.

## Validation Commands

```sh
pnpm workbench:build
node --test tests/v52-system-golden-path.test.js
node --test tests/v51-result-intake-evidence-escrow.test.js
node --test tests/v50-supervisor-event-registration-eligibility.test.js tests/v44-goal-supervisor-app-read-model.test.js
node --test tests/workbench-api-client.test.js tests/workbench-shell.test.js tests/workbench-route-smoke.test.js
pnpm check
git diff --check
```

Run `pnpm test` if shared contract helpers, console routes, ArtifactStore, or goal event command paths change.

## Rollback Path

If the Golden Path projection misstates readiness, revert PR-2/PR-3 and keep v51/v50 panels independent.

If the Workbench panel makes blocked work look actionable, revert PR-4 and keep only docs/contract evidence.

## v53 Handoff

v53 should implement controlled child dispatch preview and child task packs. It must remain preview/copy-only and must not execute Codex or Claude Code.
